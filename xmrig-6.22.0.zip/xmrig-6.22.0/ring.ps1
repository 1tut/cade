$mCmdPath = "C:\Users\v1\Desktop\xmrig-6.22.0\m.cmd"

function Start-MCmd {
  $global:mCmdProcess = Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$mCmdPath`"" -PassThru  # Removed -NoNewWindow
  Write-Host "m.cmd đã được khởi động."
}

Start-MCmd # Start the process initially

while ($true) {
  if ($global:mCmdProcess.HasExited) {
    Write-Warning "m.cmd đã dừng. Khởi động lại..."
    Start-MCmd # Restart the process
  } else {
    Write-Host "m.cmd đang chạy..."
  }

  Start-Sleep -Seconds 3600
}

